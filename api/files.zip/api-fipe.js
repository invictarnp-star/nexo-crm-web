/**
 * /api/fipe
 *
 * Ponte entre o sistema e a Tabela Fipe. Toda a lógica de qual provedor
 * usar fica AQUI — se um dia você trocar a API gratuita por uma oficial/
 * licenciada, só precisa mexer neste arquivo; o resto do sistema (o
 * formulário de veículo) continua funcionando do mesmo jeito, porque só
 * conversa com estas 4 ações:
 *
 *   GET /api/fipe?action=marcas
 *   GET /api/fipe?action=modelos&marca=CODIGO_MARCA
 *   GET /api/fipe?action=anos&marca=CODIGO_MARCA&modelo=CODIGO_MODELO
 *   GET /api/fipe?action=valor&marca=CODIGO_MARCA&modelo=CODIGO_MODELO&ano=CODIGO_ANO
 *
 * Provedor atual: fipe.parallelum.com.br (gratuito, dados oficiais da
 * Fipe, sem necessidade de chave para uso normal).
 *
 * Para trocar de provedor no futuro: mantenha os 4 formatos de resposta
 * abaixo (marcas: [{codigo,nome}], modelos: [{codigo,nome}],
 * anos: [{codigo,nome}], valor: {codigoFipe,valor,mesReferencia,
 * combustivel,marca,modelo,ano}) e só troque as chamadas fetch aqui
 * dentro pela API nova.
 */

const FIPE_BASE = "https://fipe.parallelum.com.br/api/v2";

function pickField(obj, candidates) {
  if (!obj) return "";
  const keys = Object.keys(obj);
  for (const c of candidates) {
    const found = keys.find((k) => k.toLowerCase() === c.toLowerCase());
    if (found && obj[found] != null && obj[found] !== "") return obj[found];
  }
  return "";
}

async function buscarMarcas() {
  const resp = await fetch(`${FIPE_BASE}/cars/brands`);
  if (!resp.ok) throw new Error("Não foi possível consultar as marcas.");
  const data = await resp.json();
  return data.map((m) => ({ codigo: String(m.code), nome: m.name }));
}

async function buscarModelos(marcaCodigo) {
  const resp = await fetch(`${FIPE_BASE}/cars/brands/${marcaCodigo}/models`);
  if (!resp.ok) throw new Error("Não foi possível consultar os modelos.");
  const data = await resp.json();
  const lista = data.models || data;
  return lista.map((m) => ({ codigo: String(m.code), nome: m.name }));
}

async function buscarAnos(marcaCodigo, modeloCodigo) {
  const resp = await fetch(`${FIPE_BASE}/cars/brands/${marcaCodigo}/models/${modeloCodigo}/years`);
  if (!resp.ok) throw new Error("Não foi possível consultar os anos.");
  const data = await resp.json();
  return data.map((a) => ({ codigo: String(a.code), nome: a.name }));
}

async function buscarValor(marcaCodigo, modeloCodigo, anoCodigo) {
  const resp = await fetch(`${FIPE_BASE}/cars/brands/${marcaCodigo}/models/${modeloCodigo}/years/${anoCodigo}`);
  if (!resp.ok) throw new Error("Não foi possível consultar o valor Fipe.");
  const detail = await resp.json();

  const precoTexto = pickField(detail, ["price", "valor", "Valor"]);
  const valorNumerico =
    Number(String(precoTexto).replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3},)/g, "").replace(",", ".")) || null;

  return {
    codigoFipe: pickField(detail, ["codeFipe", "codigoFipe", "CodigoFipe"]),
    valor: valorNumerico,
    mesReferencia: pickField(detail, ["referenceMonth", "mesReferencia", "MesReferencia"]),
    combustivel: pickField(detail, ["fuel", "combustivel", "Combustivel"]),
    marca: pickField(detail, ["brand", "marca", "Marca"]),
    modelo: pickField(detail, ["model", "modelo", "Modelo"]),
    ano: pickField(detail, ["modelYear", "anoModelo", "AnoModelo"]),
  };
}

export default async function handler(req, res) {
  try {
    const { action, marca, modelo, ano } = req.query;

    if (action === "marcas") {
      return res.status(200).json(await buscarMarcas());
    }
    if (action === "modelos") {
      if (!marca) return res.status(400).json({ erro: "Informe a marca." });
      return res.status(200).json(await buscarModelos(marca));
    }
    if (action === "anos") {
      if (!marca || !modelo) return res.status(400).json({ erro: "Informe marca e modelo." });
      return res.status(200).json(await buscarAnos(marca, modelo));
    }
    if (action === "valor") {
      if (!marca || !modelo || !ano) return res.status(400).json({ erro: "Informe marca, modelo e ano." });
      return res.status(200).json(await buscarValor(marca, modelo, ano));
    }
    return res.status(400).json({ erro: "Ação inválida." });
  } catch (e) {
    console.error(e);
    res.status(502).json({ erro: "Não foi possível consultar a Tabela Fipe neste momento. Tente novamente." });
  }
}
